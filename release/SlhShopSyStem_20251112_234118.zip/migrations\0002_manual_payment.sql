﻿ALTER TABLE public."orders" ADD COLUMN IF NOT EXISTS payment_proof_url text;
